sap.ui.define([
    "sap/ui/core/mvc/Controller"
], function (Controller) {
    "use strict";

    return Controller.extend("analytics.controller.App", {
        onInit: function () {}
    });
});
